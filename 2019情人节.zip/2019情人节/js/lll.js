
setTimeout(function() {
		    $("a").css({
		        position: 'relative',
		        left: '-400px',
		        opacity: 0
		    });
		    $("a").animate({
		        left: '1px',
		        opacity: 1
		    }, 2000);
		}, 100);
		
		$("#audio_btn").click(function() {
		    var music = document.getElementById("music");
		    if (music.paused) {
		        music.play();
		        $("#audio_btn").html("点击关闭背景音乐");
		    } else {
		        music.pause();
		        $("#audio_btn").html("点击播放背景音乐");
		    }
		});